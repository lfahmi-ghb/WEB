/*********************************************************************************
* WEB422 – Assignment 2
* I declare that this assignment is my own work in accordance with Seneca Academic Policy.
* No part of this assignment has been copied manually or electronically from any other source
* (including web sites) or distributed to other students.
*
* Name: Lara Fahmi     Student ID: 109742197     Date: Feb, 5th, 2021
*
* ****MY DATA TAKES A BIT OF TIME TO LOAD IN THE WEB******
*
*
*For this assignment, I was going to do my files in my Assignment 1 folder, but my static files weren't loading (like main.js). So 
* I downloaded the week02 code examples and tried to copy my content in that folder (which is this one), and then my main.js loaded. So it worked.
********************************************************************************/
//var jsdom = require('jsdom');
//const {JSDOM} = jsdom;
//const {window} = new JSDOM();
//const {document} = (new JSDOM('')).window;
//global.document = document;
//var $ = jQuery = require('jquery')(window);

let theatersModel = [];

var restaurantData = [];
var currentRestaurant = {};
var page = 1;
var perPage = 10;
let map = {
    map:null
};


  function avg(grades){
   // return grades.reduce((a, b) => a + b) / grades.length;
    var total = 0;
    for(var i= 0; i< grades.length;i++){
        total += grades[i].score;
    }
    var result = (total/grades.length).toFixed(2);
    return result
}

var tableRows = _.template(
    `<% _.forEach(restaurantData, function(restaurants){ %>
        <tr data_id=<%- restaurants._id %>>
            <td><%- restaurants.name %></td>
            <td><%- restaurants.cuisine%></td>
            <td><%- restaurants.address.building %> <%- restaurants.address.street %></td>
            <td><%- avg(restaurants.grades)%></td>     
        </tr>
   <% }); %>`
   
);


function loadRestaurantData(){
           //https://whispering-river-00864.herokuapp.com/
    fetch(`https://peaceful-oasis-15511.herokuapp.com/api/restaurants?page=${page}&perPage=${perPage}`)
    .then(res => res.json())
    .then ((json)=>{
        restaurantData = json;
        //let rowsData = tableRows({restaurants: data})) 
        let rowsData = tableRows(restaurantData);
        $("#restaurant-table tbody").html(rowsData);
        $("#current-page").html(page);
    })
    .catch(err => console.error(err))
}


function getRestaurantModelById(id){

    for(let i =0; i < restaurantData.length; i++){
        if(restaurantData[i]._id == id){
            return _.cloneDeep(restaurantData[i]);
        }

    }
    return null;
}

   
$(function() {

    loadRestaurantData();

    $("#restaurant-table tbody").on("click","tr",function(){     

        currentRestaurant = getRestaurantModelById($(this).attr("data_id"));    
        console.log(currentRestaurant);
    
        $("#restaurant-modal h4").html(`${currentRestaurant.name}`);
        $("#restaurant-address").html(`${currentRestaurant.address.building} ${currentRestaurant.address.street}`)
        $('#restaurant-modal').modal( {
           backdrop:'static',
           keyboard: false
        });
    
    
    $("#previous-page").on("click", function(event) {
        if (page > 1) {
            page--;
        }
        loadRestaurantData();
    });
    
    
    $("#next-page").on("click", function(event) {
        page++;
        loadRestaurantData();
    });
    
    $('#restaurant-modal').on('shown.bs.modal', function () {
        map = new L.Map('leaflet', {
            center: [currentRestaurant.address.coord[1], currentRestaurant.address.coord[0]],
            zoom: 18,
            layers: [
                new L.TileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png')
            ]
        });
        console.log(currentRestaurant.address.coord[1]);
        console.log(currentRestaurant.address.coord[0]);
        console.log(map);
        L.marker([currentRestaurant.address.coord[1],currentRestaurant.address.coord[0]]).addTo(map);
    });
    
            
     });
     
    
    
    
     $("#restaurant-modal").on('hidden.bs.modal',function(){
            map.off; // I added this to help removing the map object, because it gives me errors in the console saying "Map object was initialized"
            map.remove();
        })
    
    
});
