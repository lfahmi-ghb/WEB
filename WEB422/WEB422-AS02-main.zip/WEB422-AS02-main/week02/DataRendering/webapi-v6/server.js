
/*********************************************************************************
* WEB422 – Assignment 1
* I declare that this assignment is my own work in accordance with Seneca Academic Policy.
* No part of this assignment has been copied manually or electronically from any other source
* (including web sites) or distributed to other students.
*
* Name: Lara Fahmi     Student ID: 109742197         Date: Jan 20, 2021
* Heroku Link: https://whispering-river-00864.herokuapp.com/
*
********************************************************************************/ 

const express = require("express");
const cors = require("cors");
const path = require("path");
const bodyParser = require('body-parser');
const app = express();
const HTTP_PORT = process.env.PORT || 8080;
const RestaurantDB = require("./restaurantDB.js");
const db = new RestaurantDB("mongodb+srv://lfahmi1:M4t6i5@web422.pls0z.mongodb.net/sample_restaurants?retryWrites=true&w=majority");
app.use(bodyParser.json());
app.use(cors());

db.initialize().then(()=>{
  app.listen(HTTP_PORT, ()=>{
  console.log(`server listening on: ${HTTP_PORT}`);
  });
 }).catch((err)=>{
  console.log(err);
 });
 app.get('/', function(req, res){
  res.sendFile(path.join(__dirname + '/index.html'))
})

   //POST /api/restaurants
 app.post("/api/restaurants", (req, res)=>{
    res.status(201).json(db.addNewRestaurant(req.body));
})
  

//GET /api/restaurants : This route must accept the numeric query parameters "page" and "perPage" as well as the string parameter "borough",
app.get("/api/restaurants", (req, res) => {
  db.getAllRestaurants(req.query.page, req.query.perPage, req.query.borough).then((data) => {
      res.status(200).json({ data });
    }).catch((err) => {
      res.status(401).json({ "message": "Resource not found" });
    });
});

//GET /api/restaurants : This route must accept a numeric route parameter that represents the _id
app.get("/api/restaurants/:id", (req,res)=>{
  db.getRestaurantById(req.params.id)
      .then((restaurant)=>{
          res.status(200).json(restaurant)
      })
      .catch((err)=>{
          res.status(400).json(err);
      });  
  
});

// accepts a numeric route parameter that represents the _id,  It will use these values to update a specific "Restaurant"
app.put("/api/resturant/:id", (req, res) => {
  db.updateRestaurantById(req.body, req.params.id).then((data) => {
      res.status(200).json({ "message": "Updated Successfully" });
    }).catch((err) => {
      res.status(401).json({ "message": "Resource not found" });
    });
});

// accepts a numeric route parameter that represents the _id, It will use this value to delete a specific "Restaurant" 

app.delete("/api/resturant/:id", (req, res) => {
  db.deleteRestaurantById(req.params.id).then((data) => {
      res.status(200).json({ "message": "Deleted Successfully" });
    }).catch((err) => {
      res.status(401).json({ "message": "Resource not found" });
    });
});


// error 404 page

app.use((req, res) => {
  res.status(404).send("Page not found");
});

