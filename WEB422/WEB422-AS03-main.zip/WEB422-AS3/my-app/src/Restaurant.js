import { MapContainer, TileLayer, Marker } from "react-leaflet";
import { useState, useEffect } from "react";
import { Table, Pagination, CardDeck, Card, Container, Spinner } from "react-bootstrap";


function Restaurant(props) {
  const [restaurant, setRestaurant] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);

    fetch(`https://whispering-river-00864.herokuapp.com/api/restaurants/${props.id}`).then((result) => {
        return result.json();
      }) .then((data) => {
        if (data.hasOwnProperty("_id")) {
               setRestaurant(data);
        } else {
          setRestaurant(null);
        }
      }).catch((err) => {
        console.log("r.i.p" + err);
      })
      
        setLoading(false);
  }, [props.id]);


  if (!restaurant){
    return (
      <Card style={{ top: "30px", backgroundColor: "rgba(222, 252, 223, 0.904)"}}>
        <Card.Body>
          <Card.Text>Unable to find Restaurant with the id: {props.id}.</Card.Text>
        </Card.Body>
      </Card>
    );
  }
  if (loading) return(
    <div style={{ textAlign: "center" }}>
      <Spinner animation="grow" />
      <div>Loading, please wait...</div>
    </div>
  );
else {

  return (
    <Container>
      <Card style={{ backgroundColor: "rgba(222, 252, 223, 0.904)", top: "20px" }}>     
          <Card.Footer>
          <h5>{restaurant.name}</h5>
          </Card.Footer>
          <Card.Body>
            {restaurant.address.building} {restaurant.address.street} 
        </Card.Body>
      </Card>



      <MapContainer
        style={{ height: "400px", marginTop: "40px" }}
        center={[restaurant.address.coord[1], restaurant.address.coord[0]]}
        zoom={13}
        scrollWheelZoom={false}
      >
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <Marker
          position={[restaurant.address.coord[1], restaurant.address.coord[0]]}
        ></Marker>
      </MapContainer>



      <div style={{ marginTop: "10px", marginBottom: "10px" }}>
        <h5>Ratings: </h5>
        <CardDeck>
          {restaurant.grades.map((grades) => {
            return (
              <Card key={grades.date}>
                <Card.Footer>Grade: {grades.grade}</Card.Footer>
                <Card.Body>
                  Completed: {new Date(grades.date).toLocaleDateString()}
                </Card.Body>
              </Card>
            );
          })}
        </CardDeck>
      </div>
    </Container>
  );
}
}

export default Restaurant;