import { useState, useEffect } from "react";
import { Table, Card, Container, Pagination, Spinner } from "react-bootstrap";
import queryString from "query-string";
import { useHistory } from "react-router-dom";


function Restaurants(props) {
  
  const [restaurants, setRestaurants] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  let history = useHistory();



  //**** Fetching ****//
  useEffect(() => {
    // Borough can be obtained by "parsing" the value of props.query
    var boroughQ = queryString.parse(props.query).borough;    
    var resApi = `https://whispering-river-00864.herokuapp.com/api/restaurants?page=${page}&perPage=10`;

    // if there was a borough presented, then add it to the resApi, otherwise, leave it without the borough
    if (props.query) {
      resApi += `&borough=${boroughQ}`;
  }
    else { resApi = `https://whispering-river-00864.herokuapp.com/api/restaurants?page=${page}&perPage=10`;}

    fetch(resApi).then((res) => {
        return res.json();  }).then((data) => {       
        setRestaurants(data); }) .catch((err) => {
        console.log(err);
      })       
      setLoading(false);
  }, [props, page]);



    //**** Paging ****//

  const previousPage = () => {
      if (page > 1) {
          setPage(page - 1);
      }
      else setPage(page);
  };

  const nextPage = () => {
    setPage(page + 1);
  };

 
    //**** View ****//
    if (loading) return (
      <div style={{ textAlign: "center", marginTop: "100px" }}>
        <Spinner animation="grow" />
        <div>Loading, please wait...</div>
      </div>
    );
  
    if (restaurants.length === 0)
    return (
      <Card style={{ top: "30px", backgroundColor: "rgb(248, 245, 245)"}}>
        <Card.Body>
          <Card.Text>Unable to find Restaurant </Card.Text>
        </Card.Body>
      </Card>
    );
  
  if (!loading)
  return (

    <Container>

      <Card style={{ top: "15px", backgroundColor: "rgba(222, 252, 223, 0.904)" }}>
        <Card.Body>
          <Card.Title>Restaurant List</Card.Title>
          <Card.Text>
            Full list of restaurants. Optionally sorted by borough
          </Card.Text>
        </Card.Body>
      </Card>


      <Table striped bordered hover style={{ marginTop: "10px" , backgroundColor: "rgba(241, 253, 241, 0.904)"}}>
      <thead>
        <tr>
          <th>Name</th>
          <th>Address</th>
          <th>Borough</th>
          <th>Cuisine</th>
        </tr>
      </thead>
      <tbody>
        {restaurants.map((restaurant) => {
          return (

            <tr onClick={() => { history.push(`/restaurant/${restaurant._id}`);}} key={restaurant._id}>
              <td>{restaurant.name}</td>
              <td>{restaurant.address.building} {restaurant.address.street}</td>
              <td>{restaurant.borough}</td>
              <td>{restaurant.cuisine}</td>
            </tr>

          );
        })}
      </tbody>
      </Table>


      <Pagination>
        <Pagination.Prev onClick={previousPage} />
        <Pagination.Item>{page}</Pagination.Item>
        <Pagination.Next onClick={nextPage} />
      </Pagination>

    </Container>
  );




}

export default Restaurants;