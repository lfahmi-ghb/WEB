import React from 'react';
import { Table, Pagination, CardDeck, Card } from 'react-bootstrap';
function About() {
  return (
    <CardDeck>
    <Card style={{ backgroundColor: "rgba(222, 252, 223, 0.904)", top: "20px" }}>
       <Card.Footer>
       <h4> About</h4>                   
       </Card.Footer>
       <Card.Body>    
           <Card.Text> All about me - the developer </Card.Text>
           <Card.Text> My name is Lara, and I'm in CPP (Computer Programming) program at Seneca College </Card.Text>
       </Card.Body>
   </Card>
</CardDeck>
  );
}

export default About;