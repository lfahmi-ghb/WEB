  
import { Card } from "react-bootstrap";

export default function NotFound() {
  return (
    <Card style={{ top: "30px", backgroundColor: "rgb(248, 245, 245)"}}>
      <Card.Body>
        <Card.Text> Sorry. Unable to find what you are looking for.</Card.Text>
      </Card.Body>
    </Card>
  );
}