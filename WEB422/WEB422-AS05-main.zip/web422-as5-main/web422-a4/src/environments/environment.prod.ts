export const environment = {
  production: true,
  clientID: "7cee7131c8294892b40f3b733ad589ed",
  clientSecret: "ada617b9fcc943f3816bcdefb328a0ec"
};
