import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MusicDataService } from '../music-data.service';

@Component({
  selector: 'app-artist-discography',
  templateUrl: './artist-discography.component.html',
  styleUrls: ['./artist-discography.component.css'],
})

export class ArtistDiscographyComponent implements OnInit {
  albums!: any;
  artist: any ;

  constructor( private route: ActivatedRoute, private dataService: MusicDataService) {}



  ngOnInit(): void {

//It must invoke the getArtistById(id) method of the MusicDataService and subscribe to the returned Observable
    let id = this.route.snapshot.params['id'];
    this.dataService.getArtistById(id).subscribe((data) => {
      this.artist = data;
    });


//It must invoke the getAlbumsByArtistId(id) method of the MusicDataService and subscribe to the returned Observable.
    this.dataService.getAlbumsByArtistId(id).subscribe((data) => {
      var albumsList = data.items;
      const mySet = new Set();
      this.albums = albumsList.filter((album: {name: unknown}) => {
        if (mySet.has(album.name)){
          return false;  
        }
       else return mySet.add(album.name)
      });
    });
  }

}