export const environment = {
  production: true,
  clientID: "825bfb209e0e40df9bf98a5a88fb8064",
  clientSecret: "620ac3fbbfc540d6ba2e7ee06e383704",
  userAPIBase: "https://safe-gorge-21887.herokuapp.com/api/user"
};
