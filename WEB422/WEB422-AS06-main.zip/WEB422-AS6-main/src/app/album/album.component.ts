import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MusicDataService } from '../music-data.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-album',
  templateUrl: './album.component.html',
  styleUrls: ['./album.component.css']
})
export class AlbumComponent implements OnInit {
  
  album = {} as any;


  constructor( private route: ActivatedRoute, private musicdataService: MusicDataService, public snackBar: MatSnackBar ) {}

  ngOnInit(): void {
    let id = this.route.snapshot.params['id'];
    this.musicdataService.getAlbumById(id).subscribe((data) => (
      this.album = data
      ));
  }


  addToFavourites(trackID: any){
    this.musicdataService.addToFavourites(trackID).subscribe(data => {
      if (data.data.length > 0) {
        this.snackBar.open("Adding to Favourites...", "Done", { duration: 1500 });
      }
    })
  }
}
