import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms'
import { User } from '../User'
import { AuthService } from '../auth.service'
import { Router } from '@angular/router'


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: User = new User;
  loading: Boolean = false
  warning: any

  constructor(private authService: AuthService, private router:Router) { }

  ngOnInit(): void {
    this.user = new User()
  }


  onSubmit(form: NgForm): void {
    this.loading = true
    this.authService.login(this.user).subscribe(
      (success) =>{
        this.loading = false
        localStorage.setItem('access_token', success.token)
        this.router.navigate(['/newReleases'])
      },
      (err)=>{
        this.loading = false
        this.warning = err.error.message;       
      }
    )
  }

}
